import time
import utime

import machine
time.sleep(0.1) # Wait for USB to become ready

ram = [ #16x8 ram
    [0, 0, 0, 0, 0, 0, 0, 0],  # m=0  (not utilising memory loc 1 since our pc counts from 1 to 15 )
    #instruction half inst,half memory location
    [0, 0, 0, 0, 1, 0, 0, 0],  # m=1 LOAD //ci7,ci6,ci5,ci4,ci3,ci2,ci1,ci0 #LOAD
    [0, 0, 0, 1, 1, 0, 0, 1],  # m=2 ADD
    [1, 1, 1, 0, 0, 0, 0, 0],  # m=3 OUT
    [0, 0, 1, 1, 0, 1, 1, 0],  # m=4 JUMP
    [1, 1, 1, 1, 0, 0, 1, 1],  # i=5 HLT
    [0, 0, 0, 0, 1, 0, 0, 0],  # m=6 LOAD
    [0, 0, 0, 1, 1, 0, 0, 1],  # m=7 ADD
    #memory of data 8 to 15
    [0, 0, 0, 0, 0, 0, 1, 0],  # d=8 //d7,d6,d5,d4,d3,d2,d1,d0 alu me ulta dekhega
    [0, 0, 0, 0, 0, 0, 0, 1],  # d=9
    [0, 0, 0, 0, 0, 0, 0, 0],  # d=10
    [0, 0, 0, 0, 0, 0, 0, 0],  # d=11
    [0, 0, 0, 0, 0, 0, 1, 1],  # d=12
    [0, 0, 0, 0, 0, 0, 0, 0],  # d=13
    [0, 0, 0, 0, 0, 0, 1, 1],  # d=14
    [0, 0, 0, 1, 0, 0, 1, 0]   # d=15
    ]


#pin settings
# CLOCK
clock_pin = machine.Pin(0, machine.Pin.OUT)

reset = machine.Pin(1, machine.Pin.OUT)


en = machine.Pin(2, machine.Pin.OUT)
en.value(1)
reset.value(1)
reset.value(0)

#pc
p0 = machine.Pin(10, machine.Pin.IN)
p1 = machine.Pin(11, machine.Pin.IN)
p2 = machine.Pin(12, machine.Pin.IN)
p3 = machine.Pin(13, machine.Pin.IN)

#IR
ci0 = machine.Pin(16, machine.Pin.OUT)
ci1 = machine.Pin(17, machine.Pin.OUT)
ci2 = machine.Pin(18, machine.Pin.OUT)
ci3 = machine.Pin(19, machine.Pin.OUT)
ci4 = machine.Pin(20, machine.Pin.OUT)
ci5 = machine.Pin(21, machine.Pin.OUT)
ci6 = machine.Pin(22, machine.Pin.OUT)
ci7 = machine.Pin(26, machine.Pin.OUT)


#databits
d0 = machine.Pin(3, machine.Pin.OUT)
d1 = machine.Pin(4, machine.Pin.OUT)
d2 = machine.Pin(5, machine.Pin.OUT)
d3 = machine.Pin(6, machine.Pin.OUT)
d4 = machine.Pin(7, machine.Pin.OUT)
d5 = machine.Pin(8, machine.Pin.OUT)
d6 = machine.Pin(9, machine.Pin.OUT)
d7 = machine.Pin(28, machine.Pin.OUT)

#allmuxsignal pin vvvvvvimp for accumulator input
mux_acc = machine.Pin(14, machine.Pin.OUT)

d_select = machine.Pin(15, machine.Pin.OUT)

o_select = machine.Pin(27, machine.Pin.OUT)

next_pcval = 0

def provide_clockpulse():
    for _ in range(1):
        clock_pin.value(0)
        utime.sleep_ms(500)  # Adjust the delay as needed
        clock_pin.value(1)
        utime.sleep_ms(500)  # Adjust the delay as needed

while True:
    clock_pin.value(0)
    utime.sleep_ms(500)  # Adjust the delay as needed
    clock_pin.value(1)
    utime.sleep_ms(500)  # Adjust the delay as needed

    en.value(0) # now pc is at 1 so 1st insruction ko fetch kro and do execution between these
    if (next_pcval != 0):
        pcval = next_pcval
        next_pcval = 0
    else:
        pcval=(p3.value() * 8) + (p2.value() * 4) + (p1.value() * 2) + (p0.value() * 1)
    print("PC:", pcval)    
    #this whole is instruction
    ci7.value(ram[pcval][0])
    ci6.value(ram[pcval][1])
    ci5.value(ram[pcval][2])
    ci4.value(ram[pcval][3])

    ci3.value(ram[pcval][4])
    ci2.value(ram[pcval][5])
    ci1.value(ram[pcval][6])
    ci0.value(ram[pcval][7])

    provide_clockpulse()
    
    
    #instruction in format
    # c7 c6 c5 c4 -->instruction 0000 load,0001 add, 0010 sub
    # c3 c2 c1 c0 -->  memory location of the data jispe instruction chalna

    decoded_inst= (ci7.value() * 8) + (ci6.value() * 4) + (ci5.value() * 2) + (ci4.value() * 1)
    

    mem_loc= (ci3.value() * 8) + (ci2.value() * 4) + (ci1.value() * 2) + (ci0.value() * 1)
    #now fetch 8 se 15 ke bech vala data and store that in some var for now
    d7.value(ram[mem_loc][0])
    d6.value(ram[mem_loc][1])
    d5.value(ram[mem_loc][2])
    d4.value(ram[mem_loc][3])
    d3.value(ram[mem_loc][4])
    d2.value(ram[mem_loc][5])
    d1.value(ram[mem_loc][6])
    d0.value(ram[mem_loc][7]) #fetched data successfully isko yaha se bahir bhejna

    provide_clockpulse()
    #recognizing and perfroming instruction

    #OPCODES LOAD=0, ADD=1, OUT=14, SUB=2  JUMP=3  HLT= 15
    if decoded_inst == 0: #0000
        # LOAD code
        d_select.value(1)
        mux_acc.value(1) # now load value
        provide_clockpulse()
        print("LOAD successful ")
        
                
            
    elif decoded_inst == 1: #0001 add coded
        d_select.value(0) #goes to ALU input
        provide_clockpulse()
        mux_acc.value(0)
        print("ADD  ")

    #in order to view the OUT, pause at every instruction, output visible on 7 seg
    elif decoded_inst == 14: #1110 load value of acc to output reg
        o_select.value(1) 
        provide_clockpulse()
        o_select.value(0) 
        print("OUT  ")

    elif decoded_inst == 2: #0010 sub coded
        d_select.value(0)  # Goes to ALU input for subtraction
        
        for i in range(1,8,1):
            if (ram[mem_loc][i] == 0):
                ram[mem_loc][i] = 1
            else:
                ram[mem_loc][i] = 0        
        carry = 1
        for i in range(8):
            sum_bit = ram[mem_loc][i] + carry
            ram[mem_loc][i] = sum_bit % 2
            carry = sum_bit // 2
         
        print(ram[mem_loc])    
        provide_clockpulse()
        mux_acc.value(0)
        print("SUBTRACT")    

    elif decoded_inst == 3: #Jump
        print("jump to:", mem_loc)

        next_pcval = mem_loc    
        
    elif decoded_inst == 15: #1111
        # programs comes to a halt, END
        print("HALT") 
        break   
    
        
    else:
        # Handle invalid instruction or other cases
        print("Unknown opcode")



    mux_acc.value(0)
    en.value(1) #instruction ends here

    if p0.value() == 1 and p1.value() == 1 and p2.value() == 1 and p3.value() == 0:
        break

    

